# GCP IAM Bindings Module

This module manages IAM bindings at three levels of the GCP resource hierarchy:
- **Organization level**: Permissions across the entire organization
- **Folder level**: Permissions for specific folders and their children
- **Project level**: Permissions for individual projects

## File Structure

```
4-iam/
├── main.tf                    # Main Terraform configuration
├── variables.tf               # Variable definitions
├── providers.tf               # Provider configuration
├── terraform.tfvars           # Main configuration file
├── org-bindings.tfvars       # Organization IAM bindings
├── folder-bindings.tfvars    # Folder IAM bindings
└── project-bindings.tfvars   # Project IAM bindings
```

## Configuration Files

### org-bindings.tfvars
Manages IAM bindings at the organization level. These permissions apply across the entire GCP organization.

**Example:**
```hcl
org_bindings = {
  "roles/resourcemanager.organizationViewer" = [
    "group:auditors@example.com",
    "user:admin@example.com",
  ]
}
```

### folder-bindings.tfvars
Manages IAM bindings for specific folders. Folder names must match those created in `3-resource-hierarchy`.

**Example:**
```hcl
folders = {
  "billing" = {
    mode = "additive"
    bindings = {
      "roles/resourcemanager.folderEditor" = [
        "group:finance@example.com",
      ]
    }
  }
}
```

### project-bindings.tfvars
Manages IAM bindings for specific projects.

**Key format:** `"folder-project"` where:
- `folder` = folder name from resource hierarchy
- `project` = project name from resource hierarchy

**Example:**
```hcl
projects = {
  "billing-billing-logs" = {
    mode = "additive"
    bindings = {
      "roles/logging.viewer" = [
        "group:auditors@example.com",
      ]
    }
  }
}
```

## Usage

### Option 1: Apply All Bindings Together
```bash
terraform init
terraform plan \
  -var-file="org-bindings.tfvars" \
  -var-file="folder-bindings.tfvars" \
  -var-file="project-bindings.tfvars"

terraform apply \
  -var-file="org-bindings.tfvars" \
  -var-file="folder-bindings.tfvars" \
  -var-file="project-bindings.tfvars"
```

### Option 2: Apply Specific Level Only
```bash
# Organization only
terraform apply -var-file="org-bindings.tfvars"

# Folders only
terraform apply -var-file="folder-bindings.tfvars"

# Projects only
terraform apply -var-file="project-bindings.tfvars"
```

### Option 3: Use Auto Variables File
Create `terraform.auto.tfvars` and include all configurations:
```hcl
# Include content from all binding files
# This file will be automatically loaded
```

## IAM Binding Modes

### Additive Mode (Recommended)
- Adds new IAM bindings without removing existing ones
- Safe for incremental changes
- Multiple Terraform configurations can coexist

```hcl
mode = "additive"
```

### Authoritative Mode (Use with Caution)
- Replaces ALL existing IAM bindings for specified roles
- Can remove manually created bindings
- Use only when you want full control

```hcl
mode = "authoritative"
```

## Member Format

IAM bindings support the following member types:

```hcl
bindings = {
  "roles/example.role" = [
    "user:alice@example.com",                      # Individual user
    "group:engineers@example.com",                 # Google Group
    "serviceAccount:sa@project.iam.gserviceaccount.com",  # Service Account
    "domain:example.com",                          # All users in domain
  ]
}
```

## Common GCP Roles

### Organization Level
- `roles/resourcemanager.organizationAdmin` - Full control of organization
- `roles/resourcemanager.organizationViewer` - View organization resources
- `roles/billing.admin` - Manage billing accounts
- `roles/iam.organizationRoleAdmin` - Manage custom roles

### Folder Level
- `roles/resourcemanager.folderAdmin` - Full control of folder
- `roles/resourcemanager.folderEditor` - Edit folder and create projects
- `roles/resourcemanager.folderViewer` - View folder resources

### Project Level
- `roles/owner` - Full control (use sparingly)
- `roles/editor` - Modify resources (cannot manage IAM)
- `roles/viewer` - Read-only access
- `roles/compute.networkAdmin` - Manage networking
- `roles/storage.admin` - Manage storage resources
- `roles/logging.admin` - Manage logs

## Dependencies

This module depends on resources from:
- `3-resource-hierarchy`: Folders and projects must be created first
- The module references `google_folder.this` and `google_project.this`

## Best Practices

1. **Use Groups**: Assign permissions to groups, not individual users
2. **Principle of Least Privilege**: Grant minimum necessary permissions
3. **Use Additive Mode**: Safer for most use cases
4. **Separate Concerns**: Keep org/folder/project bindings in separate files
5. **Document Changes**: Comment bindings to explain why they exist
6. **Regular Audits**: Review and cleanup unused permissions

## Example: Complete Setup

1. **Create folder structure** (in `3-resource-hierarchy`)
2. **Configure organization bindings** (in `org-bindings.tfvars`):
```hcl
org_bindings = {
  "roles/resourcemanager.organizationViewer" = [
    "group:all-engineers@example.com",
  ]
}
```

3. **Configure folder bindings** (in `folder-bindings.tfvars`):
```hcl
folders = {
  "production" = {
    mode = "additive"
    bindings = {
      "roles/resourcemanager.folderEditor" = [
        "group:prod-admins@example.com",
      ]
    }
  }
}
```

4. **Configure project bindings** (in `project-bindings.tfvars`):
```hcl
projects = {
  "production-app-backend" = {
    mode = "additive"
    bindings = {
      "roles/compute.admin" = [
        "group:backend-team@example.com",
      ]
    }
  }
}
```

5. **Apply configuration**:
```bash
terraform init
terraform plan \
  -var-file="org-bindings.tfvars" \
  -var-file="folder-bindings.tfvars" \
  -var-file="project-bindings.tfvars"

terraform apply \
  -var-file="org-bindings.tfvars" \
  -var-file="folder-bindings.tfvars" \
  -var-file="project-bindings.tfvars"
```

## Troubleshooting

### Error: folder/project not found
- Ensure `3-resource-hierarchy` has been applied first
- Verify folder/project names match exactly

### Permission Denied
- Ensure Terraform service account has `roles/resourcemanager.organizationAdmin` or equivalent

### Bindings Not Applied
- Check for typos in member emails
- Verify groups exist in Google Workspace
- Confirm service accounts are created

## Security Considerations

- **Never commit sensitive data**: Use `.gitignore` for service account keys
- **Review regularly**: Audit IAM bindings quarterly
- **Use service accounts**: For automation, not user credentials
- **Enable audit logging**: Track IAM changes
- **Test in dev first**: Always validate in non-production environment
