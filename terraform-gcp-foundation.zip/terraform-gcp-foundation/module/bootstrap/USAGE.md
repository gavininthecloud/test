# Bootstrap Module Usage Guide

This module enables GCP APIs and grants IAM permissions at the organization level for your bootstrap project.

## What This Module Does

1. **Enables GCP APIs** on your bootstrap project
2. **Grants Organization-Level IAM Permissions** to users/service accounts

## Module Inputs

| Variable | Type | Description | Required |
|----------|------|-------------|----------|
| `org_id` | string | GCP Organization ID | Yes |
| `bootstrap_project_id` | string | Bootstrap project ID | Yes |
| `bootstrap_services` | set(string) | Set of GCP APIs to enable | Yes |
| `bootstrap_org_iam` | map(set(string)) | Map of email addresses to IAM roles at org level | Yes |

## Basic Usage Example

```hcl
module "bootstrap" {
  source = "./module/bootstrap"

  # Organization ID
  org_id = "456692188473"

  # Bootstrap project ID (must already exist)
  bootstrap_project_id = "cantech-terraform"

  # GCP APIs to enable on the bootstrap project
  bootstrap_services = [
    "cloudresourcemanager.googleapis.com",
    "cloudbilling.googleapis.com",
    "iam.googleapis.com",
    "serviceusage.googleapis.com",
    "compute.googleapis.com",
    "storage-api.googleapis.com"
  ]

  # Organization-level IAM permissions
  # Format: email = [list of roles]
  bootstrap_org_iam = {
    "terraform-bootstrap@cantech-terraform.iam.gserviceaccount.com" = [
      "roles/resourcemanager.organizationAdmin",
      "roles/billing.user",
      "roles/iam.securityAdmin"
    ]
    "admin@apptonate.com" = [
      "roles/resourcemanager.organizationAdmin"
    ]
  }
}
```

## Complete Example with Variables

### Step 1: Create `variables.tf`

```hcl
variable "org_id" {
  description = "GCP Organization ID"
  type        = string
}

variable "bootstrap_project_id" {
  description = "Bootstrap project ID"
  type        = string
}

variable "bootstrap_apis" {
  description = "List of APIs to enable on bootstrap project"
  type        = set(string)
  default = [
    "cloudresourcemanager.googleapis.com",
    "cloudbilling.googleapis.com",
    "iam.googleapis.com",
    "serviceusage.googleapis.com",
    "compute.googleapis.com",
    "storage-api.googleapis.com",
    "logging.googleapis.com",
    "monitoring.googleapis.com"
  ]
}

variable "service_account_email" {
  description = "Terraform service account email"
  type        = string
}

variable "admin_users" {
  description = "List of admin user emails"
  type        = list(string)
  default     = []
}
```

### Step 2: Create `main.tf`

```hcl
module "bootstrap" {
  source = "./module/bootstrap"

  org_id               = var.org_id
  bootstrap_project_id = var.bootstrap_project_id
  bootstrap_services   = var.bootstrap_apis

  # Build the IAM mapping dynamically
  bootstrap_org_iam = merge(
    # Grant permissions to the service account
    {
      (var.service_account_email) = [
        "roles/resourcemanager.organizationAdmin",
        "roles/resourcemanager.folderAdmin",
        "roles/resourcemanager.projectCreator",
        "roles/billing.user",
        "roles/iam.securityAdmin",
        "roles/serviceusage.serviceUsageAdmin"
      ]
    },
    # Grant permissions to admin users
    {
      for email in var.admin_users :
      email => [
        "roles/resourcemanager.organizationAdmin",
        "roles/billing.viewer"
      ]
    }
  )
}
```

### Step 3: Create `terraform.tfvars`

```hcl
org_id                 = "456692188473"
bootstrap_project_id   = "cantech-terraform"
service_account_email  = "terraform-bootstrap@cantech-terraform.iam.gserviceaccount.com"
admin_users            = [
  "admin@apptonate.com",
  "devops@apptonate.com"
]
```

### Step 4: Run Terraform

```bash
terraform init
terraform plan
terraform apply
```

## Advanced Example: Multiple Service Accounts

If you have different service accounts for different stages:

```hcl
module "bootstrap" {
  source = "./module/bootstrap"

  org_id               = "456692188473"
  bootstrap_project_id = "cantech-terraform"

  bootstrap_services = [
    "cloudresourcemanager.googleapis.com",
    "cloudbilling.googleapis.com",
    "iam.googleapis.com",
    "serviceusage.googleapis.com",
    "compute.googleapis.com",
    "storage-api.googleapis.com"
  ]

  bootstrap_org_iam = {
    # Bootstrap service account - full permissions
    "terraform-bootstrap@cantech-terraform.iam.gserviceaccount.com" = [
      "roles/resourcemanager.organizationAdmin",
      "roles/billing.user",
      "roles/iam.securityAdmin",
      "roles/serviceusage.serviceUsageAdmin",
      "roles/orgpolicy.policyAdmin"
    ]

    # Networking service account - limited permissions
    "terraform-network@cantech-terraform.iam.gserviceaccount.com" = [
      "roles/compute.networkAdmin",
      "roles/compute.securityAdmin"
    ]

    # Project service account - project-focused permissions
    "terraform-project@cantech-terraform.iam.gserviceaccount.com" = [
      "roles/resourcemanager.projectCreator",
      "roles/billing.user"
    ]

    # Human admin users
    "admin@apptonate.com" = [
      "roles/resourcemanager.organizationAdmin"
    ]
  }
}
```

## Real-World Example: Bootstrap with Outputs

```hcl
# main.tf

module "bootstrap" {
  source = "./module/bootstrap"

  org_id               = var.org_id
  bootstrap_project_id = var.bootstrap_project_id
  bootstrap_services   = toset([
    "cloudresourcemanager.googleapis.com",
    "cloudbilling.googleapis.com",
    "iam.googleapis.com",
    "serviceusage.googleapis.com",
    "compute.googleapis.com",
    "storage-api.googleapis.com",
    "logging.googleapis.com",
    "monitoring.googleapis.com",
    "bigquery.googleapis.com",
    "cloudkms.googleapis.com",
    "securitycenter.googleapis.com"
  ])

  bootstrap_org_iam = {
    (var.terraform_sa_email) = [
      "roles/resourcemanager.organizationAdmin",
      "roles/resourcemanager.folderAdmin",
      "roles/resourcemanager.projectCreator",
      "roles/resourcemanager.projectMover",
      "roles/billing.user",
      "roles/billing.viewer",
      "roles/billing.costsManager",
      "roles/iam.securityAdmin",
      "roles/serviceusage.serviceUsageAdmin",
      "roles/orgpolicy.policyAdmin",
      "roles/compute.xpnAdmin"
    ]
  }
}

# outputs.tf

output "enabled_apis" {
  description = "List of enabled APIs on bootstrap project"
  value       = [for api in module.bootstrap.enabled_services : api]
}

output "org_iam_bindings" {
  description = "Organization-level IAM bindings created"
  value       = "IAM bindings created for organization ${var.org_id}"
}
```

## Common Use Cases

### Use Case 1: Initial Bootstrap Setup

**Scenario:** You're setting up a brand new GCP organization.

```hcl
module "bootstrap" {
  source = "./module/bootstrap"

  org_id               = "456692188473"
  bootstrap_project_id = "cantech-terraform"

  # Minimal APIs for initial setup
  bootstrap_services = [
    "cloudresourcemanager.googleapis.com",
    "cloudbilling.googleapis.com",
    "iam.googleapis.com",
    "serviceusage.googleapis.com"
  ]

  # Just the service account that will run Terraform
  bootstrap_org_iam = {
    "terraform-bootstrap@cantech-terraform.iam.gserviceaccount.com" = [
      "roles/resourcemanager.organizationAdmin",
      "roles/billing.user"
    ]
  }
}
```

### Use Case 2: Adding New Admin User

**Scenario:** A new admin joined the team and needs organization access.

```hcl
module "bootstrap" {
  source = "./module/bootstrap"

  org_id               = "456692188473"
  bootstrap_project_id = "cantech-terraform"

  bootstrap_services = [] # No new APIs needed

  bootstrap_org_iam = {
    # Existing service account
    "terraform-bootstrap@cantech-terraform.iam.gserviceaccount.com" = [
      "roles/resourcemanager.organizationAdmin"
    ]

    # New admin user
    "newadmin@apptonate.com" = [
      "roles/resourcemanager.organizationAdmin",
      "roles/billing.viewer"
    ]
  }
}
```

### Use Case 3: Enable Additional APIs

**Scenario:** You need to enable new APIs for an upcoming feature.

```hcl
module "bootstrap" {
  source = "./module/bootstrap"

  org_id               = "456692188473"
  bootstrap_project_id = "cantech-terraform"

  # Add new APIs
  bootstrap_services = [
    "cloudresourcemanager.googleapis.com",
    "iam.googleapis.com",
    # New APIs for machine learning workload
    "aiplatform.googleapis.com",
    "notebooks.googleapis.com",
    "ml.googleapis.com"
  ]

  bootstrap_org_iam = {
    "terraform-bootstrap@cantech-terraform.iam.gserviceaccount.com" = [
      "roles/resourcemanager.organizationAdmin"
    ]
  }
}
```

## How the Module Works Internally

### 1. API Enablement

The module enables each API specified in `bootstrap_services`:

```hcl
resource "google_project_service" "bootstrap" {
  for_each                   = var.bootstrap_services
  project                    = var.bootstrap_project_id
  service                    = each.key
  disable_dependent_services = true
  disable_on_destroy         = false
}
```

### 2. IAM Mapping

The module transforms the input from:
```hcl
bootstrap_org_iam = {
  "user@example.com" = ["role1", "role2"]
}
```

Into individual IAM bindings at the organization level via the `org_iam` submodule.

## Troubleshooting

### Error: "API not enabled"

**Problem:**
```
Error: Error enabling service: Error enabling service ["xxx.googleapis.com"] for project "cantech-terraform"
```

**Solution:**
Ensure the Service Usage API is enabled first:
```bash
gcloud services enable serviceusage.googleapis.com --project=cantech-terraform
```

### Error: "Permission denied"

**Problem:**
```
Error: Error setting IAM policy for organization "456692188473": Permission denied
```

**Solution:**
The account running Terraform needs `roles/resourcemanager.organizationAdmin`. Grant it manually:
```bash
gcloud organizations add-iam-policy-binding 456692188473 \
  --member="user:your-email@apptonate.com" \
  --role="roles/resourcemanager.organizationAdmin"
```

### Error: "Service account does not exist"

**Problem:**
```
Error: Error setting IAM policy: Service account does not exist
```

**Solution:**
Create the service account first before using it in `bootstrap_org_iam`:
```bash
gcloud iam service-accounts create terraform-bootstrap \
  --project=cantech-terraform
```

## Best Practices

1. **Start Minimal:** Begin with only essential APIs and permissions, add more as needed
2. **Use Variables:** Don't hardcode values, use variables for flexibility
3. **Separate Concerns:** Use different service accounts for different stages (bootstrap, networking, projects)
4. **Document Permissions:** Always document why each permission is needed
5. **Regular Audits:** Periodically review and remove unused permissions

## Dependencies

This module depends on:
- `module/org_iam` - For organization-level IAM bindings

## Module Structure

```
module/bootstrap/
├── main.tf         # Main module logic
├── variables.tf    # Input variables
└── USAGE.md        # This file
```

## Version Requirements

- Terraform >= 1.3.0
- Google Provider >= 5.0.0

## Support

For issues or questions about this module, refer to the main bootstrap documentation in `1-bootstrap/README.md`.
