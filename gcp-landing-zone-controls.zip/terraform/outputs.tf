output "managed_policies" {
  description = "Desired policy resource names. Verify effective policy after rollout."
  value = {
    boolean = { for k, v in var.boolean_policies : k => { name = "${var.parent}/policies/${k}", enforced = v } }
    list    = { for k, v in var.list_policies : k => { name = "${var.parent}/policies/${k}", mode = v.mode, values = v.values } }
  }
}

output "custom_cicd_policies" {
  description = "Additional custom identity policy names, beyond the original Google-managed catalog."
  value       = { for k, p in google_org_policy_policy.cicd_identity : k => p.name }
}

output "custom_pubsub_policies" {
  value = google_org_policy_policy.pubsub_montreal[*].name
}
