# Proposed private-access baseline for organization 78898779993.
# Prepared for review only; no Google Cloud changes have been applied.
# Workload primary: Montreal northamerica-northeast1.
# Workload secondary: Toronto northamerica-northeast2.
# The location allowlist permits both regions and their zones; it does not
# configure primary/secondary deployment, replication, backups or failover.
parent                            = "organizations/78898779993"
quota_project_id                  = "REPLACE_WITH_QUOTA_PROJECT_ID"
custom_constraint_organization_id = "78898779993"
enforce_explicit_cicd_accounts    = true
enforce_montreal_pubsub           = true

boolean_policies = {
  # Pub/Sub region selection is separately enforced by the custom topic rule.
  "pubsub.enforceInTransitRegions" = true
  # This connector requirement applies to first-generation functions only.
  "cloudfunctions.requireVPCConnector" = true
  # Check managed-service dependencies (including GKE) before rollout.
  "compute.disableSerialPortLogging"               = true
  "compute.disableGlobalSelfManagedSslCertificate" = true
  "bigquery.disableBQOmniAWS"                      = true
  "bigquery.disableBQOmniAzure"                    = true
  "appengine.disableCodeDownload"                  = true

  # Data storage: prevent public buckets, require IAM access and HTTPS.
  "storage.publicAccessPrevention"   = true
  "storage.uniformBucketLevelAccess" = true
  "storage.secureHttpTransport"      = true

  # Cloud SQL: provision private connectivity before enforcement.
  "sql.restrictPublicIp"           = true
  "sql.restrictAuthorizedNetworks" = true

  # Private connectivity for Datastream and notebook instances.
  "datastream.disablePublicConnectivity" = true
  "ainotebooks.restrictPublicIp"         = true

  # Network provisioning: explicit VPCs and restricted public paths.
  "compute.skipDefaultNetworkCreation"          = true
  "compute.disableVpcExternalIpv6"              = true
  "compute.disableInternetNetworkEndpointGroup" = true

  # Compute Engine baseline. Prepare Linux OS Login IAM and recovery access.
  "compute.requireShieldedVm"                  = true
  "compute.requireOsLogin"                     = true
  "compute.disableNestedVirtualization"        = true
  "compute.disableSerialPortAccess"            = true
  "compute.setNewProjectDefaultToZonalDNSOnly" = true

  # Allow account creation, but do not automatically grant project roles.
  # Existing Editor grants are not removed by these policies.
  "iam.disableServiceAccountCreation"               = false
  "iam.automaticIamGrantsForDefaultServiceAccounts" = true
  "iam.disableServiceAccountKeyCreation"            = true
  "iam.disableServiceAccountKeyUpload"              = true

  # Require explicitly selected build execution identities.
  "cloudbuild.useBuildServiceAccount"   = false
  "cloudbuild.useComputeServiceAccount" = false

  # Requires Private Marketplace to be enabled separately.
  # Also configure Google's recommended Marketplace User Access Restrictions.
  "commerceorggovernance.disablePublicMarketplace" = true
}

list_policies = {
  # Block new NAT configurations pending an approved subnet allowlist.
  # Existing NAT configurations are not automatically removed.
  "compute.restrictCloudNATUsage" = {
    mode = "deny_all"
  }
  # Internal golden image publisher only. This is NOT a Shared VPC host ID.
  # Restrict workload image-creation/import IAM separately to close local-image
  # exceptions. Managed services may need scoped exceptions for their images.
  "compute.trustedImageProjects" = {
    mode   = "allow"
    values = ["projects/prj-coc-prd-bootstrap"]
  }

  "gcp.resourceLocations" = {
    mode = "allow"
    values = [
      "in:northamerica-northeast1-locations",
      "in:northamerica-northeast2-locations",
    ]
  }

  "gcp.restrictTLSVersion" = {
    mode   = "deny"
    values = ["TLS_VERSION_1", "TLS_VERSION_1_1"]
  }

  # No new VM external IPv4 assignments. Existing resources need review.
  "compute.vmExternalIpAccess" = {
    mode = "deny_all"
  }

  # Internal-only load balancing and protocol forwarding.
  "compute.restrictLoadBalancerCreationForTypes" = {
    mode   = "allow"
    values = ["in:INTERNAL"]
  }
  "compute.restrictProtocolForwardingCreationForTypes" = {
    mode   = "allow"
    values = ["INTERNAL"]
  }

  # Private Cloud Run ingress; all outbound traffic uses the configured VPC.
  # Prepare Direct VPC egress or connectors, firewall rules and NAT as needed.
  "run.allowedIngress" = {
    mode   = "allow"
    values = ["internal"]
  }
  "run.allowedVPCEgress" = {
    mode   = "allow"
    values = ["all-traffic"]
  }

  # No Shared VPC host exists yet. Leave these unmanaged until approved host
  # projects and subnets exist; do not substitute the golden-image project:
  # compute.restrictSharedVpcHostProjects
  # compute.restrictSharedVpcSubnetworks
}
