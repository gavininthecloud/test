# Pub/Sub-specific rule: other services can still use Toronto.
# https://docs.cloud.google.com/pubsub/docs/custom-constraints
variable "enforce_montreal_pubsub" {
  description = "Require Montreal-only topic message storage and in-transit enforcement on topic CREATE/UPDATE."
  type        = bool
  default     = false
  validation {
    condition     = !var.enforce_montreal_pubsub || can(regex("^[0-9]+$", var.custom_constraint_organization_id))
    error_message = "Supply the organization that owns the custom Pub/Sub constraint."
  }
}

resource "google_org_policy_custom_constraint" "pubsub_montreal" {
  count          = var.enforce_montreal_pubsub ? 1 : 0
  parent         = "organizations/${var.custom_constraint_organization_id}"
  name           = "custom.requireMontrealPubsubMessages"
  display_name   = "Require Montreal Pub/Sub message storage and transit"
  description    = "Set messageStoragePolicy.allowedPersistenceRegions to northamerica-northeast1 only and enforceInTransit to true."
  resource_types = ["pubsub.googleapis.com/Topic"]
  method_types   = ["CREATE", "UPDATE"]
  action_type    = "ALLOW"
  condition      = "has(resource.messageStoragePolicy) && resource.messageStoragePolicy.enforceInTransit && size(resource.messageStoragePolicy.allowedPersistenceRegions) == 1 && resource.messageStoragePolicy.allowedPersistenceRegions.all(r, r == 'northamerica-northeast1')"
}

resource "google_org_policy_policy" "pubsub_montreal" {
  count  = var.enforce_montreal_pubsub ? 1 : 0
  name   = "${var.parent}/policies/${google_org_policy_custom_constraint.pubsub_montreal[0].name}"
  parent = var.parent
  spec {
    rules {
      enforce = "TRUE"
    }
  }
}
