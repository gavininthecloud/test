# Cloud SQL
# Select controls through boolean_policies and list_policies. No automatic enforcement.

# Excluded: constraints/sql.restrictNoncompliantDiagnosticDataAccess — Google says not to configure manually.
# Excluded: constraints/sql.restrictNoncompliantResourceCreation — Google says not to configure manually.
resource "google_org_policy_policy" "sql_boolean" {
  for_each = { for k, v in var.boolean_policies : k => v if contains([
    "sql.restrictPublicIp",
    "sql.restrictAuthorizedNetworks"
  ], k) }
  name   = "${var.parent}/policies/${each.key}"
  parent = var.parent
  spec {
    rules {
      enforce = each.value ? "TRUE" : "FALSE"
    }
  }
}
