variable "parent" {
  description = "Existing target organization, folder, or project resource name. Prefer a pilot folder initially."
  type        = string
  validation {
    condition     = can(regex("^(organizations/[0-9]+|folders/[0-9]+|projects/[a-zA-Z0-9-]+)$", var.parent))
    error_message = "Use organizations/NUMBER, folders/NUMBER, or projects/ID_OR_NUMBER."
  }
}

variable "quota_project_id" {
  description = "Existing quota project with orgpolicy.googleapis.com enabled and serviceusage.services.use granted to the caller."
  type        = string
}

variable "boolean_policies" {
  description = "Constraint ID without constraints/. Only supplied keys are managed. False explicitly allows the constrained behavior; omission leaves policy unmanaged."
  type        = map(bool)
  default     = {}
  validation {
    condition = alltrue([for k in keys(var.boolean_policies) : contains([
      "appengine.disableCodeDownload",
      "bigquery.disableBQOmniAWS",
      "bigquery.disableBQOmniAzure",
      "cloudbuild.useComputeServiceAccount",
      "cloudbuild.useBuildServiceAccount",
      "clouddeploy.disableServiceLabelGeneration",
      "storage.publicAccessPrevention",
      "storage.uniformBucketLevelAccess",
      "storage.secureHttpTransport",
      "compute.disableAllIpv6",
      "compute.disableGlobalCloudArmorPolicy",
      "compute.disableGlobalSelfManagedSslCertificate",
      "iap.requireGlobalIapWebDisabled",
      "iap.requireRegionalIapWebDisabled",
      "compute.requireBasicQuotaInResponse",
      "compute.disableGlobalSerialPortAccess",
      "compute.disableGlobalLoadBalancing",
      "compute.disableGuestAttributesAccess",
      "compute.disableHybridCloudIpv6",
      "compute.disableSshInBrowser",
      "compute.disableNestedVirtualization",
      "compute.disableSerialPortAccess",
      "compute.disableSerialPortLogging",
      "compute.disableVpcExternalIpv6",
      "compute.disableVpcInternalIpv6",
      "compute.disableNonFIPSMachineTypes",
      "compute.requireOsConfig",
      "compute.requireOsLogin",
      "compute.setNewProjectDefaultToZonalDNSOnly",
      "compute.requireShieldedVm",
      "compute.skipDefaultNetworkCreation",
      "compute.disableInternetNetworkEndpointGroup",
      "compute.restrictXpnProjectLienRemoval",
      "datastream.disablePublicConnectivity",
      "firestore.requireP4SAforImportExport",
      "cloudfunctions.requireVPCConnector",
      "iam.disableAuditLoggingExemption",
      "iam.automaticIamGrantsForDefaultServiceAccounts",
      "iam.disableServiceAccountCreation",
      "iam.disableServiceAccountKeyCreation",
      "iam.disableServiceAccountKeyUpload",
      "iam.disableWorkloadIdentityClusterCreation",
      "iam.restrictCrossProjectServiceAccountLienRemoval",
      "gcp.disableCloudLogging",
      "essentialcontacts.disableProjectSecurityContacts",
      "commerceorggovernance.disablePublicMarketplace",
      "pubsub.enforceInTransitRegions",
      "sql.restrictPublicIp",
      "sql.restrictAuthorizedNetworks",
      "ainotebooks.disableFileDownloads",
      "ainotebooks.disableRootAccess",
      "ainotebooks.disableTerminal",
      "ainotebooks.requireAutoUpgradeSchedule",
      "ainotebooks.restrictPublicIp"
    ], k)])
    error_message = "Unknown, wrong-type, or Assured Workloads-owned boolean constraint. See control-matrix.md."
  }
}

variable "list_policies" {
  description = "Explicit list rules. Modes: allow, deny, allow_all, deny_all. Values must match each Google constraint. Parent list rules are replaced."
  type = map(object({
    mode   = string
    values = optional(list(string), [])
  }))
  default = {}
  validation {
    condition = alltrue([for k in keys(var.list_policies) : contains([
      "meshconfig.allowedVpcscModes",
      "cloudbuild.allowedIntegrations",
      "cloudkms.allowedProtectionLevels",
      "gcp.restrictCmekCryptoKeyProjects",
      "run.allowedIngress",
      "run.allowedVPCEgress",
      "run.allowedBinaryAuthorizationPolicies",
      "cloudscheduler.allowedTargetTypes",
      "storage.restrictAuthTypes",
      "compute.allowedVlanAttachmentEncryption",
      "compute.storageResourceUseRestrictions",
      "compute.vmExternalIpAccess",
      "compute.trustedImageProjects",
      "compute.restrictPrivateServiceConnectProducer",
      "compute.restrictCrossProjectServices",
      "compute.restrictDedicatedInterconnectUsage",
      "compute.restrictNonConfidentialComputing",
      "compute.restrictPartnerInterconnectUsage",
      "compute.restrictSharedVpcBackendServices",
      "compute.vmCanIpForward",
      "compute.restrictVpnPeerIPs",
      "compute.sharedReservationsOwnerProjects",
      "dataform.restrictGitRemotes",
      "cloudfunctions.restrictAllowedGenerations",
      "cloudfunctions.allowedVpcConnectorEgressSettings",
      "iam.allowServiceAccountCredentialLifetimeExtension",
      "iam.workloadIdentityPoolProviders",
      "iam.workloadIdentityPoolAwsAccounts",
      "iam.serviceAccountKeyExposureResponse",
      "compute.restrictLoadBalancerCreationForTypes",
      "compute.disablePrivateServiceConnectCreationForConsumers",
      "compute.restrictCloudNATUsage",
      "compute.restrictProtocolForwardingCreationForTypes",
      "resourcemanager.allowedExportDestinations",
      "resourcemanager.allowedImportSources",
      "resourcemanager.allowEnabledServicesForExport",
      "gcp.resourceLocations",
      "commerceorggovernance.marketplaceServices",
      "resourcemanager.accessBoundaries",
      "gcp.restrictTLSVersion",
      "ainotebooks.environmentOptions",
      "ainotebooks.restrictVpcNetworks",
      "compute.restrictSharedVpcHostProjects",
      "compute.restrictSharedVpcSubnetworks"
    ], k)])
    error_message = "Unknown or wrong-type list constraint. See control-matrix.md."
  }
  validation {
    condition = alltrue([for p in values(var.list_policies) :
      contains(["allow", "deny", "allow_all", "deny_all"], p.mode) &&
      (contains(["allow", "deny"], p.mode) ? length(p.values) > 0 : length(p.values) == 0) &&
      alltrue([for v in p.values : trimspace(v) != "" && !strcontains(v, "REPLACE")])
    ])
    error_message = "Choose one mode, supply nonempty actual values for allow/deny, and omit values for allow_all/deny_all. Replace all REPLACE placeholders."
  }
  validation {
    condition = alltrue([for k, p in var.list_policies :
      !contains(["storage.restrictAuthTypes", "gcp.restrictTLSVersion", "compute.restrictNonConfidentialComputing"], k) || p.mode == "deny"
    ])
    error_message = "Authentication-type, TLS-version, and non-confidential-computing restrictions require explicit denied values."
  }
  validation {
    condition = alltrue([for k, p in var.list_policies :
      !contains(["cloudkms.allowedProtectionLevels", "gcp.restrictCmekCryptoKeyProjects", "run.allowedIngress", "run.allowedVPCEgress", "cloudfunctions.allowedVpcConnectorEgressSettings", "cloudfunctions.restrictAllowedGenerations", "cloudscheduler.allowedTargetTypes", "meshconfig.allowedVpcscModes", "resourcemanager.allowEnabledServicesForExport", "iam.serviceAccountKeyExposureResponse"], k) || p.mode == "allow"
    ])
    error_message = "This template requires explicit allow values for allow-only/settings constraints."
  }
  validation {
    condition = alltrue([for k, p in var.list_policies :
      k != "iam.serviceAccountKeyExposureResponse" || (length(p.values) == 1 && alltrue([for v in p.values : contains(["DISABLE_KEY", "WAIT_FOR_ABUSE"], v)]))
    ])
    error_message = "Choose exactly one key-exposure response: DISABLE_KEY or WAIT_FOR_ABUSE."
  }
  validation {
    condition     = !contains(keys(var.list_policies), "resourcemanager.accessBoundaries") || startswith(var.parent, "organizations/")
    error_message = "resourcemanager.accessBoundaries is evaluated only at organization level."
  }
}
