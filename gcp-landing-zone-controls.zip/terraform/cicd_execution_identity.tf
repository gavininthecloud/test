# Additional custom constraints, beyond the original 103-control catalog.
# Sources: https://docs.cloud.google.com/build/docs/custom-constraints
#          https://docs.cloud.google.com/deploy/docs/custom-org-policy
variable "custom_constraint_organization_id" {
  description = "Organization that owns custom constraints, even when enforcement targets a pilot folder."
  type        = string
  default     = null
  validation {
    condition     = !var.enforce_explicit_cicd_accounts || can(regex("^[0-9]+$", var.custom_constraint_organization_id))
    error_message = "Supply the owning organization number when enabling custom CI/CD identity constraints."
  }
}

variable "enforce_explicit_cicd_accounts" {
  description = "Create and enforce custom Cloud Build and Cloud Deploy user-managed execution identity rules. Pilot API enforcement before production."
  type        = bool
  default     = false
}

locals {
  # Accept an email or full resource name. Excludes Compute/App Engine default
  # domains, legacy Build accounts, and service-agent account names.
  cicd_user_account_pattern       = "^(projects/[^/]+/serviceAccounts/)?[a-z][a-z0-9-]*@[a-z][a-z0-9-]*[.]iam[.]gserviceaccount[.]com$"
  cicd_explicit_account_condition = "has(resource.serviceAccount) && resource.serviceAccount.matches('${local.cicd_user_account_pattern}') && !resource.serviceAccount.matches('(^|.*/)service-[^@]*@.*')"
  cicd_identity_constraints = {
    "custom.requireBuildExecutionIdentity" = {
      resource  = "cloudbuild.googleapis.com/Build"
      methods   = ["CREATE"]
      condition = local.cicd_explicit_account_condition
    }
    "custom.requireBuildTriggerExecutionIdentity" = {
      resource  = "cloudbuild.googleapis.com/BuildTrigger"
      methods   = ["CREATE", "UPDATE"]
      condition = local.cicd_explicit_account_condition
    }
    "custom.requireDeployTargetExecutionIdentity" = {
      resource = "clouddeploy.googleapis.com/Target"
      methods  = ["CREATE", "UPDATE"]
      # Multi-target aggregators do not execute jobs; their child targets do.
      # Use modern serviceAccount, not deprecated defaultPool/privatePool fields.
      condition = "has(resource.multiTarget) || (size(resource.executionConfigs) > 0 && resource.executionConfigs.all(c, has(c.serviceAccount) && c.serviceAccount.matches('${local.cicd_user_account_pattern}') && !c.serviceAccount.matches('(^|.*/)service-[^@]*@.*') && !has(c.defaultPool) && !has(c.privatePool)))"
    }
    "custom.requireDeployAutomationIdentity" = {
      resource  = "clouddeploy.googleapis.com/Automation"
      methods   = ["CREATE", "UPDATE"]
      condition = local.cicd_explicit_account_condition
    }
  }
}

resource "google_org_policy_custom_constraint" "cicd_identity" {
  for_each       = var.enforce_explicit_cicd_accounts ? local.cicd_identity_constraints : {}
  parent         = "organizations/${var.custom_constraint_organization_id}"
  name           = each.key
  display_name   = "Require an explicit user-managed execution identity"
  description    = "Supply a user-managed service account. Default execution accounts and service agents are not allowed. Targets must use executionConfigs.serviceAccount; multi-target aggregators are exempt."
  action_type    = "ALLOW"
  method_types   = each.value.methods
  resource_types = [each.value.resource]
  condition      = each.value.condition
}

resource "google_org_policy_policy" "cicd_identity" {
  for_each = google_org_policy_custom_constraint.cicd_identity
  name     = "${var.parent}/policies/${each.value.name}"
  parent   = var.parent
  spec {
    rules {
      enforce = "TRUE"
    }
  }
}
