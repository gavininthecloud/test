# Google Kubernetes Engine
# Select controls through boolean_policies and list_policies. No automatic enforcement.

# Excluded: constraints/container.restrictNoncompliantDiagnosticDataAccess — Google says not to configure manually.