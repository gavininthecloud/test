# Compute Engine, Resource Manager
# Select controls through boolean_policies and list_policies. No automatic enforcement.

# Excluded: constraints/compute.disableInstanceDataAccessApis — Google says not to configure manually.
# Excluded: constraints/compute.enableComplianceMemoryProtection — Google says not to configure manually.
resource "google_org_policy_policy" "compute_boolean" {
  for_each = { for k, v in var.boolean_policies : k => v if contains([
    "compute.disableAllIpv6",
    "compute.disableGlobalCloudArmorPolicy",
    "compute.disableGlobalSelfManagedSslCertificate",
    "compute.requireBasicQuotaInResponse",
    "compute.disableGlobalSerialPortAccess",
    "compute.disableGlobalLoadBalancing",
    "compute.disableGuestAttributesAccess",
    "compute.disableHybridCloudIpv6",
    "compute.disableSshInBrowser",
    "compute.disableNestedVirtualization",
    "compute.disableSerialPortAccess",
    "compute.disableSerialPortLogging",
    "compute.disableVpcExternalIpv6",
    "compute.disableVpcInternalIpv6",
    "compute.disableNonFIPSMachineTypes",
    "compute.requireOsConfig",
    "compute.requireOsLogin",
    "compute.setNewProjectDefaultToZonalDNSOnly",
    "compute.requireShieldedVm",
    "compute.skipDefaultNetworkCreation",
    "compute.disableInternetNetworkEndpointGroup",
    "compute.restrictXpnProjectLienRemoval"
  ], k) }
  name   = "${var.parent}/policies/${each.key}"
  parent = var.parent
  spec {
    rules {
      enforce = each.value ? "TRUE" : "FALSE"
    }
  }
}

resource "google_org_policy_policy" "compute_list" {
  for_each = { for k, v in var.list_policies : k => v if contains([
    "compute.allowedVlanAttachmentEncryption",
    "compute.storageResourceUseRestrictions",
    "compute.vmExternalIpAccess",
    "compute.trustedImageProjects",
    "compute.restrictPrivateServiceConnectProducer",
    "compute.restrictCrossProjectServices",
    "compute.restrictDedicatedInterconnectUsage",
    "compute.restrictNonConfidentialComputing",
    "compute.restrictPartnerInterconnectUsage",
    "compute.restrictSharedVpcBackendServices",
    "compute.vmCanIpForward",
    "compute.restrictVpnPeerIPs",
    "compute.sharedReservationsOwnerProjects",
    "compute.restrictLoadBalancerCreationForTypes",
    "compute.disablePrivateServiceConnectCreationForConsumers",
    "compute.restrictCloudNATUsage",
    "compute.restrictProtocolForwardingCreationForTypes",
    "compute.restrictSharedVpcHostProjects",
    "compute.restrictSharedVpcSubnetworks"
  ], k) }
  name   = "${var.parent}/policies/${each.key}"
  parent = var.parent
  spec {
    inherit_from_parent = false
    rules {
      allow_all = each.value.mode == "allow_all" ? "TRUE" : null
      deny_all  = each.value.mode == "deny_all" ? "TRUE" : null
      dynamic "values" {
        for_each = contains(["allow", "deny"], each.value.mode) ? [each.value] : []
        content {
          allowed_values = values.value.mode == "allow" ? values.value.values : null
          denied_values  = values.value.mode == "deny" ? values.value.values : null
        }
      }
    }
  }
}
