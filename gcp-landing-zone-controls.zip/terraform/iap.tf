# Compute Engine, Multiple Google Cloud services
# Select controls through boolean_policies and list_policies. No automatic enforcement.

resource "google_org_policy_policy" "iap_boolean" {
  for_each = { for k, v in var.boolean_policies : k => v if contains([
    "iap.requireGlobalIapWebDisabled",
    "iap.requireRegionalIapWebDisabled"
  ], k) }
  name   = "${var.parent}/policies/${each.key}"
  parent = var.parent
  spec {
    rules {
      enforce = each.value ? "TRUE" : "FALSE"
    }
  }
}
