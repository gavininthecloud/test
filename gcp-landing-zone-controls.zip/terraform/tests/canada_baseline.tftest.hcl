# Run with: terraform test '-var-file=terraform.tfvars'
# Mocked plan only: no Google Cloud credentials or API calls.
mock_provider "google" {}

run "canada_private_access_baseline" {
  command = plan

  assert {
    condition = alltrue([for k in [
      "pubsub.enforceInTransitRegions", "cloudfunctions.requireVPCConnector",
      "compute.disableSerialPortLogging", "compute.disableGlobalSelfManagedSslCertificate",
      "storage.secureHttpTransport", "bigquery.disableBQOmniAWS",
      "bigquery.disableBQOmniAzure", "appengine.disableCodeDownload"
    ] : lookup(var.boolean_policies, k, false)])
    error_message = "All eight requested baseline switches must remain selected."
  }
  assert {
    condition     = google_org_policy_custom_constraint.pubsub_montreal[0].resource_types == tolist(["pubsub.googleapis.com/Topic"]) && google_org_policy_policy.pubsub_montreal[0].spec[0].rules[0].enforce == "TRUE"
    error_message = "Enforce the Pub/Sub-specific region rule without narrowing the organization-wide Toronto allowance."
  }

  assert {
    condition     = google_org_policy_policy.sql_boolean["sql.restrictPublicIp"].spec[0].rules[0].enforce == "TRUE" && google_org_policy_policy.sql_boolean["sql.restrictAuthorizedNetworks"].spec[0].rules[0].enforce == "TRUE"
    error_message = "Cloud SQL must retain both public-access restrictions."
  }
  assert {
    condition     = google_org_policy_policy.compute_list["compute.restrictCloudNATUsage"].spec[0].rules[0].deny_all == "TRUE"
    error_message = "NAT must remain blocked pending an approved subnet list."
  }
  assert {
    condition     = google_org_policy_policy.cloudbuild_boolean["cloudbuild.useBuildServiceAccount"].spec[0].rules[0].enforce == "FALSE" && google_org_policy_policy.cloudbuild_boolean["cloudbuild.useComputeServiceAccount"].spec[0].rules[0].enforce == "FALSE"
    error_message = "Neither default Cloud Build identity option should be enabled."
  }
  assert {
    condition     = length(google_org_policy_custom_constraint.cicd_identity) == 4 && alltrue([for c in google_org_policy_custom_constraint.cicd_identity : c.action_type == "ALLOW" && length(c.condition) <= 1000])
    error_message = "Create the four explicit identity rules within the CEL size limit."
  }

  assert {
    condition     = var.parent == "organizations/78898779993"
    error_message = "The organization baseline must target the supplied organization."
  }
  assert {
    condition = google_org_policy_policy.gcp_list["gcp.resourceLocations"].spec[0].rules[0].values[0].allowed_values == tolist([
      "in:northamerica-northeast1-locations",
      "in:northamerica-northeast2-locations",
    ])
    error_message = "Allow Montreal and Toronto location groups, including their zones."
  }
  assert {
    condition     = google_org_policy_policy.iam_boolean["iam.disableServiceAccountCreation"].spec[0].rules[0].enforce == "FALSE" && google_org_policy_policy.iam_boolean["iam.automaticIamGrantsForDefaultServiceAccounts"].spec[0].rules[0].enforce == "TRUE"
    error_message = "Permit service-account creation while blocking automatic IAM grants to covered default accounts."
  }
  assert {
    condition     = google_org_policy_policy.compute_list["compute.trustedImageProjects"].spec[0].rules[0].values[0].allowed_values == tolist(["projects/prj-coc-prd-bootstrap"])
    error_message = "Trust only the user-specified internal golden-image project."
  }
  assert {
    condition     = !contains(keys(var.list_policies), "compute.restrictSharedVpcHostProjects") && !contains(keys(var.list_policies), "compute.restrictSharedVpcSubnetworks")
    error_message = "Do not invent a Shared VPC host or subnet allowlist before they exist."
  }
  assert {
    condition     = google_org_policy_policy.compute_list["compute.vmExternalIpAccess"].spec[0].rules[0].deny_all == "TRUE" && google_org_policy_policy.run_list["run.allowedIngress"].spec[0].rules[0].values[0].allowed_values == tolist(["internal"])
    error_message = "The private baseline must restrict VM public IPv4 and Cloud Run ingress."
  }
}
