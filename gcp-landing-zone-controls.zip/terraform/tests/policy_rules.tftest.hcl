mock_provider "google" {}

variables {
  parent           = "organizations/123456789012"
  quota_project_id = "validation-project"
}

run "policy_rule_shapes" {
  command = plan
  variables {
    boolean_policies = {
      "storage.publicAccessPrevention"    = true
      "cloudbuild.useBuildServiceAccount" = false
    }
    list_policies = {
      "gcp.restrictTLSVersion"     = { mode = "deny", values = ["TLS_VERSION_1", "TLS_VERSION_1_1"] }
      "run.allowedIngress"         = { mode = "allow", values = ["internal"] }
      "compute.vmExternalIpAccess" = { mode = "deny_all" }
      "compute.vmCanIpForward"     = { mode = "allow_all" }
    }
  }
  assert {
    condition     = google_org_policy_policy.storage_boolean["storage.publicAccessPrevention"].spec[0].rules[0].enforce == "TRUE"
    error_message = "The public access prevention policy must be enforced."
  }
  assert {
    condition     = google_org_policy_policy.cloudbuild_boolean["cloudbuild.useBuildServiceAccount"].spec[0].rules[0].enforce == "FALSE"
    error_message = "An explicit false policy must not be dropped from management."
  }
  assert {
    condition     = google_org_policy_policy.gcp_list["gcp.restrictTLSVersion"].spec[0].rules[0].values[0].denied_values == tolist(["TLS_VERSION_1", "TLS_VERSION_1_1"])
    error_message = "TLS versions must appear in denied values."
  }
  assert {
    condition     = google_org_policy_policy.run_list["run.allowedIngress"].spec[0].rules[0].values[0].allowed_values == tolist(["internal"])
    error_message = "Ingress settings must appear in allowed values."
  }
  assert {
    condition     = google_org_policy_policy.compute_list["compute.vmExternalIpAccess"].spec[0].rules[0].deny_all == "TRUE" && length(google_org_policy_policy.compute_list["compute.vmExternalIpAccess"].spec[0].rules[0].values) == 0
    error_message = "Deny-all must not contain an explicit values block."
  }
  assert {
    condition     = google_org_policy_policy.compute_list["compute.vmCanIpForward"].spec[0].rules[0].allow_all == "TRUE" && length(google_org_policy_policy.compute_list["compute.vmCanIpForward"].spec[0].rules[0].values) == 0
    error_message = "Allow-all must not contain an explicit values block."
  }
}

run "reject_assured_workloads_manual_override" {
  command = plan
  variables {
    boolean_policies = { "compute.disableInstanceDataAccessApis" = true }
  }
  expect_failures = [var.boolean_policies]
}

run "reject_tls_allow_direction" {
  command = plan
  variables {
    list_policies = { "gcp.restrictTLSVersion" = { mode = "allow", values = ["TLS_VERSION_1"] } }
  }
  expect_failures = [var.list_policies]
}

run "reject_empty_allow_values" {
  command = plan
  variables {
    list_policies = { "run.allowedIngress" = { mode = "allow", values = [] } }
  }
  expect_failures = [var.list_policies]
}

run "reject_folder_visibility_boundary" {
  command = plan
  variables {
    parent        = "folders/123456789012"
    list_policies = { "resourcemanager.accessBoundaries" = { mode = "allow", values = ["under:organizations/123456789012"] } }
  }
  expect_failures = [var.list_policies]
}
