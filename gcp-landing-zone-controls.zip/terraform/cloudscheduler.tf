# Cloud Scheduler
# Select controls through boolean_policies and list_policies. No automatic enforcement.

resource "google_org_policy_policy" "cloudscheduler_list" {
  for_each = { for k, v in var.list_policies : k => v if contains([
    "cloudscheduler.allowedTargetTypes"
  ], k) }
  name   = "${var.parent}/policies/${each.key}"
  parent = var.parent
  spec {
    inherit_from_parent = false
    rules {
      allow_all = each.value.mode == "allow_all" ? "TRUE" : null
      deny_all  = each.value.mode == "deny_all" ? "TRUE" : null
      dynamic "values" {
        for_each = contains(["allow", "deny"], each.value.mode) ? [each.value] : []
        content {
          allowed_values = values.value.mode == "allow" ? values.value.values : null
          denied_values  = values.value.mode == "deny" ? values.value.values : null
        }
      }
    }
  }
}
