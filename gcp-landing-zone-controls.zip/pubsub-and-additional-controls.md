# Pub/Sub Montreal and additional requested controls

All eight requested switches are selected in the shared `terraform.tfvars`. Storage HTTPS was already enabled; seven boolean selections and one custom Pub/Sub policy have been added.

| Control | Setting | Scope |
|---|---|---|
| `pubsub.enforceInTransitRegions` | `true` | Set in-transit enforcement for new topics. |
| `cloudfunctions.requireVPCConnector` | `true` | Require a connector for first-generation functions. |
| `compute.disableSerialPortLogging` | `true` | Disable VM serial-port logging to Cloud Logging (formerly Stackdriver). |
| `compute.disableGlobalSelfManagedSslCertificate` | `true` | Block new global self-managed SSL certificates; not Google-managed or regional self-managed certificates. |
| `storage.secureHttpTransport` | `true`, retained | Reject unencrypted HTTP access to Cloud Storage. This is not a universal HTTPS rule for every service. |
| `bigquery.disableBQOmniAWS` | `true` | Block BigQuery Omni AWS processing. |
| `bigquery.disableBQOmniAzure` | `true` | Block BigQuery Omni Azure processing. |
| `appengine.disableCodeDownload` | `true` | Restrict downloading source previously uploaded to App Engine; not source downloads from every Google Cloud service. |

Sources: [Google constraint catalog](https://docs.cloud.google.com/organization-policy/reference/org-policy-constraints), [Cloud Storage transport restriction](https://docs.cloud.google.com/storage/docs/org-policy-constraints).

## Pub/Sub: Montreal baseline

The general location policy continues allowing Montreal and Toronto for other services. A Pub/Sub in-transit boolean alone does not choose Montreal: new topics without an explicit storage policy can inherit both allowed locations. To enforce your Pub/Sub request specifically, `pubsub_montreal.tf` adds `custom.requireMontrealPubsubMessages` for Topic CREATE/UPDATE. It requires exactly `northamerica-northeast1` and in-transit enforcement enabled. Topic creation with an inherited two-region policy must be changed to specify Montreal explicitly. This rule is a restriction, not a service that automatically rewrites or fills topic fields.

Use this block in your workload's `google_pubsub_topic` resources:

```hcl
message_storage_policy {
  allowed_persistence_regions = ["northamerica-northeast1"]
  enforce_in_transit          = true
}
```

No topic resources or topic names are invented in this organization-policy package. Existing topics are not automatically migrated, and existing stored messages are not relocated by a policy change. Inventory topic settings, update them through their owning configuration, and test publishers, subscribers and push endpoints. Clients outside the permitted region need a supported locational or regional endpoint targeting Montreal. A Pub/Sub Toronto disaster-recovery path requires an explicit policy/configuration change or a scoped exception; it is not silently enabled by the general two-region allowlist. This does not control every data type such as topic metadata and IAM settings.

Sources: [Pub/Sub message storage and in-transit behavior](https://docs.cloud.google.com/pubsub/docs/resource-location-restriction), [supported custom Topic fields](https://docs.cloud.google.com/pubsub/docs/custom-constraints), [Terraform topic policy fields](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/pubsub_topic).

## Dependencies to check before applying

- First-generation functions need existing, reachable VPC connectors. Second-generation functions use the existing `run.allowedVPCEgress` setting in this baseline. Strict golden-image source restrictions can conflict with the image project required for connectors, so review a scoped managed-service exception. NAT remains restricted; connectors do not by themselves provide an approved outbound path.
- Serial-port *access* was already disabled. Serial-port *logging* is now disabled too, as requested. Google documents that some dependent services, including GKE, can malfunction under the logging restriction; test them before organization-wide rollout and design exceptions if needed.
- Use supported certificate alternatives before attempting deployments that previously created global self-managed SSL certificates.
- Custom Pub/Sub CEL must be tested against Google Cloud's API, including omitted fields, before live enforcement. Mocked Terraform tests do not validate Google's CEL compiler or service normalization.

Sources: [Serial output logging](https://docs.cloud.google.com/compute/docs/troubleshooting/viewing-serial-port-output), [constraint dependencies](https://docs.cloud.google.com/organization-policy/reference/org-policy-constraints).
