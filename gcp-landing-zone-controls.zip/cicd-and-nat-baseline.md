# NAT, keys, CI/CD identities and private Cloud SQL

## Selected settings

| Requirement | Configuration |
|---|---|
| Restrict Cloud NAT | `compute.restrictCloudNATUsage`: `deny_all` pending approved subnets |
| Prevent new user-managed keys | `iam.disableServiceAccountKeyCreation=true` |
| Prevent key uploads | `iam.disableServiceAccountKeyUpload=true` |
| Avoid default Cloud Build execution identities | Both `cloudbuild.useBuildServiceAccount` and `cloudbuild.useComputeServiceAccount` are `false` |
| Require user-managed CI/CD execution identities | Four additional custom constraints, created and enforced from `cicd_execution_identity.tf` |
| Keep Cloud SQL private | `sql.restrictPublicIp=true` and `sql.restrictAuthorizedNetworks=true` |

## Cloud NAT

No subnet has been approved yet, so the baseline explicitly denies all new covered NAT usage/configurations. When approved subnets exist, replace deny-all with an explicit allow list of actual subnet resource names. This is independent of whether those subnets are in Shared VPC or ordinary project VPCs. Existing NAT configurations continue to work and need separate review. This policy can block gateway or subnet creation that would violate it; it is not an instant switch that removes existing NAT or all internet egress. Private workloads requiring internet access need an approved alternate path or a reviewed subnet exception.

Source: [Cloud NAT organization policies](https://docs.cloud.google.com/nat/docs/org-policy-constraints).

## Explicit CI/CD identities

The original supplied catalog has no Cloud Deploy boolean that requires an explicit execution account. The package now adds custom organization policies using Google's documented Build, BuildTrigger, Target and Automation fields:

- `custom.requireBuildExecutionIdentity`: Build CREATE must identify a user-managed account.
- `custom.requireBuildTriggerExecutionIdentity`: trigger CREATE/UPDATE must identify a user-managed account.
- `custom.requireDeployTargetExecutionIdentity`: target CREATE/UPDATE must explicitly set modern `executionConfigs.serviceAccount` on all execution configurations. Deprecated defaultPool/privatePool configurations are intentionally not accepted by this baseline. Multi-target aggregators are exempt because execution occurs on child targets.
- `custom.requireDeployAutomationIdentity`: automation CREATE/UPDATE must identify a user-managed account.

The conditions accept an explicitly supplied `*.iam.gserviceaccount.com` email (or its service-account resource name) and reject the Compute/App Engine default-account domains, legacy Cloud Build accounts and `service-` account names. They do not select or create execution accounts and do not establish an approved-account allowlist. IAM still determines which account a caller is allowed to use. A naming-pattern restriction alone does not establish ownership, purpose or least privilege.

Cloud Deploy requires its Google-managed service agent separately. Leave it provisioned with the documented service permissions. These policies target job execution and automation identities, not the internal service agent. Build and Deploy identities need appropriate execution/runtime permissions; callers need narrowly scoped `iam.serviceAccounts.actAs`. Existing targets/triggers may need remediation before updates succeed. Inventory legacy configurations before enforcement. Workloads submitted by other managed services can be affected by the Build CREATE rule too.

Sources: [Cloud Build default-account combinations](https://docs.cloud.google.com/build/docs/cloud-build-service-account-updates), [Cloud Build supported custom fields](https://docs.cloud.google.com/build/docs/custom-constraints), [Cloud Deploy supported custom fields](https://docs.cloud.google.com/deploy/docs/custom-org-policy), [Cloud Deploy identities](https://docs.cloud.google.com/deploy/docs/cloud-deploy-service-account).

## What developers must supply

For Cloud Build, explicitly supply the account in the trigger or build configuration, for example this schematic build fragment:

```yaml
serviceAccount: projects/YOUR_PROJECT_ID/serviceAccounts/YOUR_BUILD_ACCOUNT@YOUR_PROJECT_ID.iam.gserviceaccount.com
options:
  logging: CLOUD_LOGGING_ONLY
```

Provide the required log-writing permissions or another supported user-specified-account logging configuration. For Cloud Deploy Terraform targets, set the account directly in an execution block:

```hcl
execution_configs {
  usages          = ["RENDER", "DEPLOY"]
  service_account = var.clouddeploy_execution_service_account_email
}
```

Make that workload variable required with no default, and validate that it is a user-managed account. Explicitly cover any additional execution usages your pipeline enables. Configure automation accounts explicitly too. These are integration examples, not extra workload resources automatically created by the org-policy root. Actual account emails were not supplied and are not invented.

Source: [Terraform Cloud Deploy target fields](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/clouddeploy_target).

## Deployment validation

The main root now creates four custom-constraint definitions owned by `custom_constraint_organization_id=78898779993` and enforces their policies at `parent`. This also works for a separate pilot folder if the owning organization ID stays unchanged. Set `enforce_explicit_cicd_accounts=false` only when deliberately excluding these rules from a fresh deployment; changing it after management will plan their removal.

Terraform provider-schema validation and mocked plans pass. They do not compile/evaluate CEL in Google's service or prove whether a service normalizes missing fields before evaluation. Pilot these custom constraints using Google Cloud dry-run/Policy Simulator where supported, test omitted identities, explicit default accounts, valid user-managed accounts, legacy target configurations and managed-service builds, then enforce at the intended scope. The package does not claim this live API validation has happened. Confirm CREATE/UPDATE behavior and account formats in your pilot before organization-wide application.

## Cloud SQL

Both public-access restrictions remain selected. Provision and test private IP/PSC connectivity supported by your database design. Existing public instances and access paths need service-specific remediation; this package creates policies rather than databases, routing or DNS.

Source: [Cloud SQL organization policies](https://docs.cloud.google.com/sql/docs/postgres/org-policy/configure-org-policy).
