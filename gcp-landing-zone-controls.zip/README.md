# Google Cloud landing-zone organization-policy package

Prepared 2 November 2026. This implements the organization-policy layer requested in the supplied list. It does not create a complete landing zone: the organization, folders, billing, projects, Shared VPC, routing, DNS, firewall rules, NAT, private access, IAM, centralized logging, KMS and workload resources must be provisioned separately.

The current `terraform/terraform.tfvars` selects **38 Google-managed policies plus 5 custom policies** for organization `78898779993`. General resource locations allow Montreal and Toronto; Pub/Sub's specific custom rule requires Montreal. The baseline trusts `prj-coc-prd-bootstrap` and includes Marketplace, Compute Engine, NAT and service-account guardrails. There is no Shared VPC host allowlist yet. Read `organization-baseline.md`, `cicd-and-nat-baseline.md` and `pubsub-and-additional-controls.md` for prerequisites and coverage limits. Replace the quota project placeholder before planning. This input file has not been applied.

## Deliverables

- `control-matrix.md`: all 103 controls, with service, service type, operational impact rating, recommendation, prerequisites and a direct Google documentation link.
- `controls.json`: the same records in structured form; includes the supplied policy names for the two mismatched rows.
- `terraform/`: one root configuration with service-specific `.tf` files. Terraform loads all of these files together. `examples/` contains per-service input references, not separate modules or independent state deployments.

## Corrections and decisions

1. The first Datastream title is paired with `appengine.disableCodeDownload`, which controls App Engine source downloads. The actual Datastream control is already present separately.
2. The Cloud Operations serial-port title is paired with `clouddeploy.disableServiceLabelGeneration`. The actual serial logging control is already present separately.
3. Do not assume every boolean should be true. Disabling IAP, restricting global Cloud Armor maintenance, disabling GKE Workload Identity, and disabling Healthcare application logging can conflict with the intended security design. These are conditional or discouraged in the matrix.
4. For explicitly selected Cloud Build identities, the example sets both default-service-account policies to false. Google also documents other supported combinations, including both true for mixed legacy/new-project behavior; both true is not categorically invalid. Match the policy to your approved identity model.
5. Five controls in the supplied list are explicitly owned by Assured Workloads. Google’s catalog says: “Do not configure or modify this policy.” They are excluded from manual Terraform and rejected by its input validation:
   - `compute.disableInstanceDataAccessApis`
   - `compute.enableComplianceMemoryProtection`
   - `container.restrictNoncompliantDiagnosticDataAccess`
   - `sql.restrictNoncompliantDiagnosticDataAccess`
   - `sql.restrictNoncompliantResourceCreation`
6. `cloudfunctions.requireVPCConnector` and `cloudfunctions.allowedVpcConnectorEgressSettings` target first-generation functions. Use the appropriate Cloud Run settings for second generation. The Cloud Run ingress control is not exclusively a second-generation-function control.
7. `gcp.restrictCmekCryptoKeyProjects` limits key sources but does not itself mandate CMEK. `run.allowedBinaryAuthorizationPolicies` limits policy selection and should not be treated as proof that attestation checks cannot be bypassed. Implement mandatory enforcement separately as required.
8. Do not broadly block PSC or NAT without designing private service access and egress. Do not combine cross-project backend and Shared VPC backend restrictions without reviewing their documented interaction.
9. Location restrictions affect supported resource creation and are not a complete contractual data residency guarantee. A multi-region value is not equivalent to a location group.
10. The listed `ainotebooks.*` IDs remain in the catalog. Older user-managed notebooks are deprecated; verify the selected product/API generation before relying on any notebook control. `PRIVATE_MARKETPLACE` in `marketplaceServices` no longer enables Private Marketplace.

## Inputs you must supply

Choose the existing organization/folder/project target and quota project. For list controls, supply approved locations, VPC hosts/subnets, image and key projects, providers and AWS accounts, external organizations, repositories, VPN peers, integration hosts and permitted service settings. No organization-specific values were invented.

## Prepare access

Use Terraform >=1.9 and <2.0. The configuration uses the Google provider 7.x. Commit the generated provider lock file after initialization and review provider updates through your normal process. Authenticate with Application Default Credentials or an approved federated automation identity. The deployment identity needs `roles/orgpolicy.policyAdmin` at the target scope, plus `serviceusage.services.use` on the quota project. Enable `orgpolicy.googleapis.com` in that existing quota project; API enablement and IAM grants are intentionally bootstrap prerequisites.

For an interactive workstation, if applicable:

```powershell
gcloud auth application-default login
gcloud auth application-default set-quota-project QUOTA_PROJECT_ID
gcloud services enable orgpolicy.googleapis.com --project=QUOTA_PROJECT_ID
```

## Configure and deploy

The current `terraform.tfvars` already contains your organization baseline. Edit that file directly and replace its quota project placeholder; do not overwrite it with the generic example. For a separate pilot deployment, use a separate directory/state and set a pilot folder as the parent. Add entries from service examples only after reviewing the matrix. An empty input map manages no policies; it does not prove existing inherited policy is permissive. Do not pass multiple per-service files with the same map variable expecting Terraform to merge them: later map assignments replace earlier ones. Merge entries into one authoritative map.

```powershell
Set-Location terraform
terraform init
terraform fmt -check
terraform validate
terraform plan '-out=landing-zone.tfplan'
terraform show landing-zone.tfplan
terraform apply landing-zone.tfplan
```

The code uses `google_org_policy_policy` (v2) and strips the `constraints/` prefix from policy resource names. It supports boolean enforcement and explicit list allow/deny modes. List settings replace ancestor list rules (`inherit_from_parent=false`). Review effective inherited values before selecting replacement values. Only organization scope is accepted for the visibility-boundary constraint. Some list controls accept only one direction or specific enum values; common dangerous direction mistakes are validated, but the Google API remains authoritative for complete value validation.

Boolean false is an explicit override, not an omitted setting. Omitting a map key leaves a previously unmanaged policy untouched; removing a key already managed by this state plans policy deletion and can restore inherited/default behavior. Review deletes carefully. Do not use `terraform destroy` as a general rollback strategy. Retain pre-change policy exports and state, restore reviewed prior settings, and verify effective policy.

## Existing policies and verification

Inspect current and effective policy before deployment. For example:

```powershell
gcloud org-policies describe storage.publicAccessPrevention --folder=FOLDER_ID
gcloud org-policies describe storage.publicAccessPrevention --folder=FOLDER_ID --effective
```

Import an existing explicit policy before managing it in this configuration:

```powershell
terraform import 'google_org_policy_policy.storage_boolean["storage.publicAccessPrevention"]' 'folders/FOLDER_ID/policies/storage.publicAccessPrevention'
```

After import, examine the plan: a simple unconditional rule can replace existing conditional exceptions or other policy details. This template does not preserve those automatically. Design tag-based exceptions or separate scope configurations if needed. Use separate state/configuration for each deployment scope; do not switch the parent of an existing state to deploy a second scope.

After application, re-read effective policy, allow for propagation, and test both an intended compliant operation and a prohibited operation. Test build execution, VM administration and recovery, private SQL access, serverless egress, storage clients and notebook workflows as applicable. Many controls are not retroactive; enforcement does not automatically remediate existing resources. Dry-run and Policy Simulator support varies by constraint: do not assume these legacy IDs all support either feature.

## Official references

- [Google constraint catalog](https://docs.cloud.google.com/organization-policy/reference/org-policy-constraints)
- [Google security foundations preventative controls](https://docs.cloud.google.com/architecture/blueprints/security-foundations/preventative-controls)
- [Cloud Build account policy combinations](https://docs.cloud.google.com/build/docs/cloud-build-service-account-updates)
- [Service account restrictions](https://docs.cloud.google.com/organization-policy/restrict-service-accounts)
- [Cloud Storage controls and denied authentication types](https://docs.cloud.google.com/storage/docs/org-policy-constraints)
- [Cloud Run VPC Service Controls and network settings](https://docs.cloud.google.com/run/docs/securing/using-vpc-service-controls)
- [Load balancing controls](https://docs.cloud.google.com/load-balancing/docs/org-policy-constraints)
- [Cloud NAT controls](https://docs.cloud.google.com/nat/docs/org-policy-constraints)
- [Compute managed constraints and rollout](https://docs.cloud.google.com/compute/docs/access/managed-constraints)
- [Assured Workloads updates](https://docs.cloud.google.com/assured-workloads/docs/apply-updates)
- [Workbench release notes and generation changes](https://docs.cloud.google.com/gemini-enterprise-agent-platform/notebooks/workbench/release-notes)
- [HashiCorp google_org_policy_policy resource](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/org_policy_policy)

## Validation

See `VALIDATION.md` for the checks actually performed. No Google Cloud resources were changed and no authenticated plan was run.
