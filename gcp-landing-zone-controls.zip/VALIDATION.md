# Validation performed

Verified 2 November 2026.

- All 103 supplied constraint IDs matched entries in the official Google constraint catalog downloaded during this review. All supplied types matched: 59 boolean and 44 list.
- The matrix contains 103 rows and a Google documentation anchor for every row. Each anchor was checked against the catalog HTML IDs.
- Terraform covers all 98 manually configurable controls across service-specific files. The five Assured Workloads-owned controls are documented and rejected as manual inputs.
- Terraform 1.13.5 with HashiCorp Google provider 7.46.2: `terraform validate` passed.
- `terraform fmt -check -recursive` passed for configuration and test files.
- Original package tests: 5 passed, 0 failed, using a mocked Google provider. These test true/false boolean generation, allowed and denied values, allow-all and deny-all rule shapes, and rejection of a manually managed Assured Workloads policy, an incorrect TLS direction, empty allow values, and a folder-scoped visibility boundary.
- The provider lock file is included. It records the provider selected during validation.

No authenticated Google Cloud plan or apply was performed. Mocked tests validate Terraform behavior; they do not establish that your organization supports every constraint, that every proposed value is accepted by the Google API, or that applications remain functional. Organization-specific IDs, list values, existing policy imports, conditional exceptions, inherited settings and workload behavior still require deployment validation.

## Organization baseline update

- Added `terraform/terraform.tfvars` for organization `78898779993`, selecting 10 boolean and 7 list policies.
- Location values allow Montreal and Toronto location groups, including their zones. Primary/secondary placement, replication and failover are not provisioned by the allowlist.
- Updated Terraform validation and formatting checks passed.
- Updated mocked tests: **6 passed, 0 failed**. The new test checks the organization target, both region groups, selected-control count and private-access rules. Run in PowerShell with `terraform test '-var-file=terraform.tfvars'`.
- Quota project ID remains a placeholder. No authenticated plan or apply was run.

## Extended organization baseline

- Current selection: **28 policies — 20 boolean and 8 list**.
- Added the approved image source `projects/prj-coc-prd-bootstrap`, Marketplace restriction, five Compute Engine controls and four service-account controls.
- Confirmed the intended IAM combination in a mocked plan: `iam.disableServiceAccountCreation=false` and `iam.automaticIamGrantsForDefaultServiceAccounts=true`.
- Mocked assertions verify that the golden-image source matches the user-provided project and that no Shared VPC host/subnet restrictions are fabricated.
- Terraform validation passed; all **6 mocked test runs passed** with the current baseline variables. Formatting passed.
- Documented the Marketplace enablement prerequisite, local-image exceptions, managed-service image dependencies, existing IAM grant remediation and service-agent differences. These are deployment prerequisites or coverage limits, not features validated against a live organization.
- No IAM bindings, Marketplace feature toggles, projects, networks or cloud policies were changed.

## NAT and explicit CI/CD identities

- Current selection: 31 Google-managed policies plus 4 custom identity policies; 4 custom-constraint definitions are also planned.
- Terraform provider-schema validation passed. All 6 mocked test runs passed after adding assertions for private SQL, NAT deny-all, both Cloud Build default settings and the four custom definitions.
- Custom CEL conditions use fields listed by Google for Cloud Build and Cloud Deploy. Google-side CEL compilation, field normalization and API enforcement have NOT been tested; pilot validation is required before applying organization-wide.
- Key creation/upload restrictions were retained. Cloud SQL public-IP and authorized-network restrictions were retained. Existing resources, keys and IAM permissions were not modified.

## Pub/Sub Montreal and additional controls

- Current selection: **38 Google-managed policies (29 boolean, 9 list) plus 5 custom policies**. Five custom-constraint definitions are also planned.
- Seven requested booleans were added. The eighth requested switch, Storage secure HTTP transport, was already enabled and retained.
- Added a Pub/Sub Topic CREATE/UPDATE custom rule requiring exactly Montreal (`northamerica-northeast1`) with in-transit enforcement. General resource locations still allow Montreal and Toronto.
- Terraform validation passed. All 6 mocked test runs passed, with additional assertions for the eight requested switches and the Pub/Sub-specific policy. Formatting passed.
- Google-side CEL validation, application behavior and dependent service compatibility remain untested. No topics or other cloud resources were changed.
