# Proposed private-access baseline for organization 78898779993

Primary workload region: **Montreal — `northamerica-northeast1`**.
Secondary workload region: **Toronto — `northamerica-northeast2`**.

The shared `terraform/terraform.tfvars` now selects **38 Google-managed policies (29 boolean and 9 list) plus 5 custom policies**: four CI/CD identity rules and one Montreal Pub/Sub rule. It targets `organizations/78898779993`. The internal golden-image project is `prj-coc-prd-bootstrap`. No Shared VPC host project exists yet. Replace `quota_project_id` with the project approved for API quota/billing before planning; the image project is not automatically assumed to fill that role. No resources or policies have been deployed. See `pubsub-and-additional-controls.md` for the latest eight requested switches and their prerequisites.

## Location and transport

| Constraint (prefix `constraints/` omitted) | Proposed setting | Simple explanation |
|---|---|---|
| `gcp.resourceLocations` | Allow `in:northamerica-northeast1-locations`, `in:northamerica-northeast2-locations` | Permit supported resource creation in Montreal, Toronto and their zones. |
| `gcp.restrictTLSVersion` | Deny `TLS_VERSION_1`, `TLS_VERSION_1_1` | Reject old TLS versions on services that support this control. |

The location policy does not choose a default region or rank one region above another. Workload Terraform must explicitly deploy primary resources to Montreal and secondary resources to Toronto. Replication, backups and failover must be configured for each service. The proposed allowlist excludes `global` and other multi-regions; review services requiring those locations before applying at organization scope. This policy applies only to supported resources and does not guarantee that all service processing or data remains in these two cities.

Sources: [Google region IDs](https://docs.cloud.google.com/compute/docs/regions-zones), [resource location policies and value groups](https://docs.cloud.google.com/organization-policy/restrict-locations), [TLS restriction](https://docs.cloud.google.com/organization-policy/reference/org-policy-constraints#constraints/gcp.restrictTLSVersion).

## Data storage and data services

| Constraint (prefix `constraints/` omitted) | Proposed setting | Simple explanation |
|---|---|---|
| `storage.publicAccessPrevention` | `true` | Prevent access to buckets and objects through public IAM/ACL grants. |
| `storage.uniformBucketLevelAccess` | `true` | Require IAM instead of separate bucket and object ACL permissions. |
| `storage.secureHttpTransport` | `true` | Require HTTPS for Cloud Storage requests. |
| `sql.restrictPublicIp` | `true` | Prevent configuring public IP addresses on Cloud SQL. |
| `sql.restrictAuthorizedNetworks` | `true` | Prevent configuring authorized networks for Cloud SQL public access. |
| `datastream.disablePublicConnectivity` | `true` | Require private connectivity methods for Datastream. |
| `ainotebooks.restrictPublicIp` | `true` | Restrict public IPs on applicable new notebook instances. |

Prepare private SQL and Datastream connectivity, private notebook access, and IAM permissions before rollout. Storage public access prevention does not block every internet path to an authenticated resource and does not replace VPC Service Controls. Signed URLs remain a separate sharing mechanism to review. If customer-managed encryption keys are required, supply approved key project IDs and specify which services must use CMEK; the key-source constraint alone does not require CMEK.

Sources: [Storage controls](https://docs.cloud.google.com/storage/docs/org-policy-constraints), [SQL controls](https://docs.cloud.google.com/sql/docs/postgres/org-policy/configure-org-policy), [Datastream control](https://docs.cloud.google.com/organization-policy/reference/org-policy-constraints#constraints/datastream.disablePublicConnectivity), [notebook control](https://docs.cloud.google.com/organization-policy/reference/org-policy-constraints#constraints/ainotebooks.restrictPublicIp).

## Networking and application access

| Constraint (prefix `constraints/` omitted) | Proposed setting | Simple explanation |
|---|---|---|
| `compute.skipDefaultNetworkCreation` | `true` | Do not automatically create a default VPC in new projects. |
| `compute.vmExternalIpAccess` | Deny all | Prevent external IPv4 assignment to VMs in scope. |
| `compute.disableVpcExternalIpv6` | `true` | Restrict external IPv6 use in VPC networks. |
| `compute.disableInternetNetworkEndpointGroup` | `true` | Prevent internet NEGs used as external load-balancer origins. |
| `compute.restrictLoadBalancerCreationForTypes` | Allow `in:INTERNAL` | Permit internal load balancer types only. |
| `compute.restrictProtocolForwardingCreationForTypes` | Allow `INTERNAL` | Permit internal protocol forwarding only. |
| `run.allowedIngress` | Allow `internal` | Require Cloud Run ingress settings classified as internal. |
| `run.allowedVPCEgress` | Allow `all-traffic` | Route Cloud Run outbound traffic through its configured VPC connection. |

Provision explicit VPCs/subnets, DNS, firewall rules, Private Google Access or approved PSC endpoints, private administration, and VPC egress before enforcing. Routing through a VPC does not itself block internet egress. The latest user-requested baseline blocks new NAT configurations until approved subnet exceptions are supplied; see below. Keep IAP and Cloud Armor available for approved use. A public application would require a reviewed exception to this proposed internal-only baseline.

Sources: [Compute organization policies](https://docs.cloud.google.com/compute/docs/access/organization-policies), [load balancer controls](https://docs.cloud.google.com/load-balancing/docs/org-policy-constraints), [Cloud Run ingress](https://docs.cloud.google.com/run/docs/securing/ingress), [Cloud Run VPC settings](https://docs.cloud.google.com/run/docs/securing/using-vpc-service-controls).

## Additional foundation work

These selected controls reduce public exposure for the listed services. They do not disable every public endpoint across Google Cloud. Configure private GKE control-plane access and private nodes, first-generation function ingress if used, restricted IAM, audit logs, encryption, backups, and VPC Service Controls separately where required. Existing public resources must be inventoried and remediated according to each constraint's enforcement behavior. API endpoints that remain public can still be protected by authentication and service-specific access controls.

## Internal golden images

| Constraint | Selected setting | Meaning |
|---|---|---|
| `compute.trustedImageProjects` | Allow `projects/prj-coc-prd-bootstrap` | Restrict covered image-source projects to your internal golden-image project. No public publisher projects are allowlisted. |

The image project is independent of the future Shared VPC host project. Confirm that it exists, contains maintained approved images, and is accessible to the identities that deploy VMs. Grant image consumers the required `roles/compute.imageUser` access at the appropriate image or project scope, rather than broad Editor access. Limit image publication and modification to the approved image pipeline.

**Coverage limit:** this legacy policy does not restrict custom images in the local project, image files in Cloud Storage, or local image creation. Restrict image creation/import permissions in workload projects and control the build pipeline; the project allowlist alone cannot prove every VM uses a golden image. This package does not invent IAM principals or change existing IAM bindings. An image-building project that needs public upstream base images will need a deliberate, scoped image-source exception. A narrow exception is also needed for any managed service that requires its own image project; do not add public publishers organization-wide without review. In particular, Serverless VPC Access connectors can require `serverless-vpc-access-images`; consider Direct VPC egress or an approved scoped exception.

Source: [Trusted image policies, limitations, and service dependencies](https://docs.cloud.google.com/compute/docs/images/restricting-image-access).

## Marketplace

| Constraint | Selected setting | Meaning |
|---|---|---|
| `commerceorggovernance.disablePublicMarketplace` | `true` | Select the supplied public-Marketplace restriction policy. |

**Required setup outside these Terraform org policies:** enable Private Marketplace and configure approved product collections. Google's catalog says the selected constraint only works when Private Marketplace is enabled. Google recommends **Marketplace User Access Restrictions** for current governance; enable that feature and assign Marketplace access only to approved procurement users/admins. These Marketplace feature settings and group role assignments are not performed by this package. Enabling Private Marketplace alone does not stop users navigating to the public Marketplace.

Do not set `marketplaceServices=PRIVATE_MARKETPLACE` as an enablement shortcut: that value no longer has an effect. Marketplace access controls are not a replacement for restrictions on VM image sources, product deployment permissions, existing subscriptions or direct API provisioning.

Sources: [Constraint and prerequisite](https://docs.cloud.google.com/organization-policy/reference/org-policy-constraints#constraints/commerceorggovernance.disablePublicMarketplace), [enable Private Marketplace](https://docs.cloud.google.com/marketplace/docs/governance/enable-private-marketplace), [Marketplace User Access Restrictions](https://docs.cloud.google.com/marketplace/docs/governance/strict-user-access).

## Compute Engine additions

These add to the existing private-IP, explicit-VPC and internal-load-balancing controls above.

| Constraint | Selected setting | Meaning / prerequisite |
|---|---|---|
| `compute.requireShieldedVm` | `true` | Require Shielded-compatible VM creation; validate golden images and managed services. |
| `compute.requireOsLogin` | `true` | Require OS Login behavior governed by this legacy constraint; prepare Linux login roles and test existing-project metadata separately. |
| `compute.disableNestedVirtualization` | `true` | Prevent nested hypervisors except through reviewed exceptions. |
| `compute.disableSerialPortAccess` | `true` | Restrict interactive serial-console access; prepare recovery access first. |
| `compute.setNewProjectDefaultToZonalDNSOnly` | `true` | Set zonal internal DNS defaults for new projects; review application DNS assumptions. |

OS Login does not grant access by itself. Grant `roles/compute.osLogin` or, only where required, `roles/compute.osAdminLogin` to approved users/groups at the appropriate scope; additional permissions can be needed for attached service accounts or external users. This org-policy package grants no login roles. OS Login is not the Windows administration mechanism. Serial-port access and logging are separate controls; the latest request selects both restrictions. Check logging-dependent services such as GKE before enforcement. OS Config, FIPS-only machines, disabling internal IPv6 and Confidential Computing remain conditional decisions rather than new defaults.

Sources: [Compute controls](https://docs.cloud.google.com/compute/docs/access/organization-policies), [OS Login requirements](https://docs.cloud.google.com/compute/docs/oslogin/set-up-oslogin), [constraint details](https://docs.cloud.google.com/organization-policy/reference/org-policy-constraints).

## Default service accounts and IAM permissions

| Constraint | Selected setting | Meaning |
|---|---|---|
| `iam.disableServiceAccountCreation` | `false` | Do not block service-account creation through this constraint; callers still need IAM permission. |
| `iam.automaticIamGrantsForDefaultServiceAccounts` | `true` | Prevent automatic project IAM grants to the covered default App Engine and Compute Engine accounts when created. |
| `iam.disableServiceAccountKeyCreation` | `true` | Prevent new user-managed keys; use attached identities, impersonation or federation. |
| `iam.disableServiceAccountKeyUpload` | `true` | Prevent uploading externally generated service-account keys. |

**Your intended behavior:** default accounts can still be provisioned, but they do not automatically receive broad project permissions. Grant each account only the workload roles it needs, at the narrowest applicable scope. For example, a VM agent might need `roles/logging.logWriter` and `roles/monitoring.metricWriter`; an application reading a particular bucket might need `roles/storage.objectViewer` on that bucket. These are workload-dependent examples, not blanket grants and not new resources in this package. Do not grant project Editor as a convenience.

The automatic-grants control does not revoke existing Editor bindings and does not prohibit an administrator from manually granting Editor later. Inventory existing grants and replace them after impact testing. It is not a universal control over all automatically created identities: service agents have service-specific role requirements, and the legacy Cloud Build account uses a different role model. Do not remove roles from all Google-managed service agents indiscriminately. Existing independent or managed constraints may still restrict account creation even though this particular legacy constraint is set to false.

Sources: [Default Compute Engine account, Editor grants, and service agents](https://docs.cloud.google.com/compute/docs/access/service-accounts), [service-account organization policies](https://docs.cloud.google.com/organization-policy/restrict-service-accounts), [Cloud Build identity differences](https://docs.cloud.google.com/build/docs/cloud-build-service-account-updates).

## Shared VPC host project is pending

`compute.restrictSharedVpcHostProjects` and `compute.restrictSharedVpcSubnetworks` remain unselected. Neither the golden-image project nor a fabricated host project is inserted as a host/subnet allowlist. Private VPC networking can be provisioned in ordinary projects before adopting Shared VPC. Once the approved host and regional subnets exist, add their actual IDs to the shared `list_policies` map. The Terraform code for both restrictions is already in `compute.tf`.

## Execution

The latest NAT and CI/CD identity additions are described in `cicd-and-nat-baseline.md`. Cloud SQL retains both `sql.restrictPublicIp=true` and `sql.restrictAuthorizedNetworks=true`; the baseline does not provision private SQL connectivity or remediate existing public instances.

1. Read `README.md` for authentication, API enablement, permissions, existing policy imports, and state management.
2. Enter the real quota project ID in `terraform/terraform.tfvars`.
3. Review all proposed values and inherited policy before applying at organization scope. Consider a separate pilot configuration/state first.
4. In the `terraform` folder, run `terraform init`, `terraform validate`, and `terraform plan '-out=landing-zone.tfplan'`.
5. Review the plan, then apply only when ready: `terraform apply landing-zone.tfplan`.

There is one shared variables file and one shared tfvars file. Service-specific `.tf` files all read those inputs. Do not run them separately.
